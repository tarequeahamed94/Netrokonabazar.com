import React, { useState } from 'react';

function App() {
  const [cart, setCart] = useState([]);
  const products = [
    { id: 1, name: 'Cotton T-Shirt', price: 450 },
    { id: 2, name: 'Ladies Handbag', price: 1200 },
    { id: 3, name: 'Smart Watch', price: 2500 },
  ];

  const addToCart = (product) => setCart([...cart, product]);

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial' }}>
      <h1>🛒 CityMart BD</h1>
      <p>Your Trusted Online Shop in Town</p>
      <h2>Products</h2>
      <div style={{ display: 'flex', gap: '20px' }}>
        {products.map((p) => (
          <div key={p.id} style={{ border: '1px solid #ddd', padding: '10px', borderRadius: '8px' }}>
            <h3>{p.name}</h3>
            <p>৳{p.price}</p>
            <button onClick={() => addToCart(p)}>Add to Cart</button>
          </div>
        ))}
      </div>

      <h2>Cart ({cart.length})</h2>
      <ul>
        {cart.map((item, i) => (
          <li key={i}>{item.name} - ৳{item.price}</li>
        ))}
      </ul>
    </div>
  );
}

export default App;